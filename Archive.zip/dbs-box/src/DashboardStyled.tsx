import styled from 'styled-components';

export const Container = styled.div`
  height: 100%;
  width: 100%;
  margin: 20px;
  padding: 10px 20px;
  box-sizing: border-box;
  border: 2px solid grey;
  font-weight: bolder;
`;

export const RealTimeHeader = styled.div`
  height: 1.8rem;
  line-height: 1.7rem;
  background-color: #049f0b;
  color: white;
  text-align: center;
`;

export const HeaderRow = styled.div`
  margin-top: 0.5rem;
  display: flex;
  justify-content: space-between;
`;

export const ColumnHeader = styled.span`
  border: 1px solid slategray;

  margin: 5px;
  width: 100%;
  flex: 1 1 auto;
  text-align: center;

  th {
    width: 100%;
    border: 1px solid slategray;
    padding: 5px;
  }
`;

export const TableRow = styled.span`
  margin-top: 0.5rem;
  display: flex;
  justify-content: space-between;
  >span: nth-child(-n + 2) {
    color: #13c31b;
  }
  >span: nth-child(3) > div {
    background-color: #green;
  }
`;

export const RowData = styled.span`
  padding: 0 1rem;
  margin: 5px;
  width: 10rem;
  flex: 1 1 auto;
  font-size: 0.9rem;
  margin: auto;
  font-weight: bold;
`;

export const Circle = styled.div`
  border-radius: 50%;
  width: 3.5rem;
  height: 3.5rem;
  line-height: 3.2rem;
  background-color: red;
  text-align: center;
  margin-left:20px
  
  color: white;

  span{
    position: absolute;
    margin-left:300px;
  }
`;

export const CircleSub = styled.div`
  position: absolute;
  margin-left: 55px;
  margin-top: -45px;
`;

export const BoxHead = styled.div`
  border: 1px solid slategray;
  margin: 5px;
  width: 100%;
  flex: 1 1 auto;
  text-align: center;
  `;

  export const MainContent = styled.div`
  display: flex;
            flex-direction: row;
  `;

  export const Child = styled.div`
  display: flex;
            flex-direction: row;
  width: 50%;
  padding:10px;
  
  `;

  export const ChildWrapper = styled.div`
  border: 1px solid slategray;
  padding:20px
  display: flex;
            flex-direction: row;

            table ,th , td {
              padding:10px;
            }
  `;

export const UpArw = styled.div`

  width: 0; 
  height: 0; 
  border-left: 15px solid transparent;
  border-right: 15px solid transparent;

  border-bottom: 15px solid red;
`;

  

