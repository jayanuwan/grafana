import React from 'react';
import {
  Container,
  UpArw,
  BoxHead,
  MainContent,
  Child,
  Circle,
  CircleSub,
  ChildWrapper
} from './DashboardStyled';



const Dashboard = () => {
  

  return (
    <Container>
      

      <BoxHead>Help & support View<div>(Digital Customers)</div></BoxHead>
      <MainContent>
          <Child style={{'lineHeight':'40px'}}>
             # Issue <Circle> 10 <CircleSub> vs 3</CircleSub></Circle>
          </Child>
          <Child>
          <ChildWrapper>

          <table>
            <tr>
              <th>Top call keyword</th>
              <th>Volume</th>
            </tr>
            <tr>
              <td>Login</td>
              <td>9 issues</td>
            </tr>
            <tr>
              <td>Not working</td>
              <td>9 issues</td>
            </tr>
            <tr>
              <td>Transfer issue</td>
              <td>5 issues</td>
            </tr>
            <tr>
              <td>Slowness</td>
              <td>7 issues</td>
            </tr>
            </table>
          </ChildWrapper>
          </Child>
      </MainContent>

      <MainContent>
          <Child style={{'lineHeight':'40px'}}>
             # Calls <Circle> 500 <CircleSub> vs 150</CircleSub></Circle>
          </Child>
          <Child>
          <ChildWrapper>
          <table>
            <tr>
              <th>Top call drivers above baseline</th>
              <th>Call Volume</th>
            </tr>
            <tr>
              <td>Login issues</td>
              <td><MainContent>100 calls (20%) <UpArw></UpArw></MainContent></td>
            </tr>
            <tr>
              <td>Fund Transfer</td>
              <td><MainContent>70 calls (10%)<UpArw></UpArw></MainContent></td>
            </tr>
            
            </table>
            
          </ChildWrapper>
          </Child>
      </MainContent>
      
    </Container>
  );
};

export default Dashboard;
