import React from 'react';
import {
  Circle,
  ColumnHeader,
  Container,
  HeaderRow,
  RealTimeHeader,
  RowData,
  TableRow,
  CircleSub,
} from './DashboardStyled';
// import axios from 'axios';

interface TableHeaders {
  [key: string]: string;
}

const Dashboard = () => {
  // const [gridData, setGridData] = useState<any>([{}]);
  // const headers: TableHeaders = {
  //   journeyDetails: 'Journey',
  //   journeyTotalImpactedCustomers: 'NCI/Total Customers',
  //   journeyDropofRate: 'Dropoff Rate %',
  //   functionalError:'',
  //   technicalErrors:'',
  //   behaviouralTime: '14s',
  //     timeTaken: 'TBC',
  // };
  // axios.post(`https://5c282973-ad6e-45bd-94bb-9c382297ab6b.mock.pstmn.io/data/query`).then((res) => {
  //   const data = res.data;
  //   console.log('here -->', data);
  //   setGridData(data);
  // });
  // axios.get(`https://nci-api.dev.apps.cs.sgp.dbs.com/api/journies`).then((res) => {
  //   const data = res.data;
  //   console.log('here -->', data.content);
  //   setGridData(data.content);
  // });

  const rowData: TableHeaders[] = [
    {
      journeyDetails: 'Personal Particular Update Address',
      journeyTotalImpactedCustomers: '1000 / 30000',
      journeyDropofRate: '82%',
      functionalError: '40',
      technicalErrors: '0.5%',
      behaviouralTime: '14s',
      timeTaken: 'TBC',
    },
    {
      journeyDetails: 'Journey 2 Sub Journey',
      journeyTotalImpactedCustomers: 'AA / BBBB',
      journeyDropofRate: 'X%',
      functionalError: '40',
      technicalErrors: '0.5%',
      behaviouralTime: '14s',
      timeTaken: 'TBC',
    },
    {
      journeyDetails: 'Journey 2 Sub Journey',
      journeyTotalImpactedCustomers: 'AA / BBBB',
      journeyDropofRate: 'X%',
      functionalError: '40',
      technicalErrors: '0.5%',
      behaviouralTime: '14s',
      timeTaken: 'TBC',
    },
    {
      journeyDetails: 'Journey 2 Sub Journey',
      journeyTotalImpactedCustomers: 'AA / BBBB',
      journeyDropofRate: 'X%',
      functionalError: '40',
      technicalErrors: '0.5%',
      behaviouralTime: '14s',
      timeTaken: 'TBC',
    },
    {
      journeyDetails: 'Journey 2 Sub Journey',
      journeyTotalImpactedCustomers: 'AA / BBBB',
      journeyDropofRate: 'X%',
      functionalError: '40',
      technicalErrors: '0.5%',
      behaviouralTime: '14s',
      timeTaken: 'TBC',
    },
  ];

  // setGridData(rowData);

  return (
    <Container>
      <RealTimeHeader>Real-time view of past 30 minutes - refreshed every 30 minutes </RealTimeHeader>
      {/* <HeaderRow>
        {Object.keys(headers).map((key: string) => (
          <ColumnHeader key="">{headers[key]}</ColumnHeader>
        ))}
      </HeaderRow> */}
      <HeaderRow>
        <ColumnHeader key="">Journey</ColumnHeader>
        <ColumnHeader key="">NCI/Total Customers</ColumnHeader>
        <ColumnHeader key="">Dropoff Rate %</ColumnHeader>
        <ColumnHeader key="">
          Error Rate %
          <tr>
            <th>Functional Errors</th>
            <th>Technical Errors</th>
          </tr>
        </ColumnHeader>
        <ColumnHeader key="">
          Time Taken (sec)
          <tr>
            <th>Behavioural Time</th>
            <th>Performance Time</th>
          </tr>
        </ColumnHeader>
      </HeaderRow>
      {rowData.map((row: any) => (
        <TableRow key="">
          <RowData style={{ width: '300px' }} key="">
            {row.journeyDetails}
          </RowData>
          <RowData style={{ width: '300px' }} key="">
            {row.journeyTotalImpactedCustomers}
          </RowData>
          <RowData style={{ width: '300px', lineHeight: '10px' }} key="">
            <Circle>
              {row.journeyDropofRate}
              <CircleSub>vs 8%</CircleSub>
            </Circle>{' '}
          </RowData>
          <RowData key="">
            <Circle>
              {row.functionalError}
              <CircleSub>vs 8%</CircleSub>
            </Circle>
          </RowData>
          <RowData key="">
            <Circle>
              {row.technicalErrors}
              <CircleSub>vs 8%</CircleSub>
            </Circle>
          </RowData>
          <RowData key="">
            <Circle>
              {row.behaviouralTime}
              <CircleSub>vs 8%</CircleSub>
            </Circle>
          </RowData>
          <RowData key="">
            <Circle>
              {row.timeTaken}
              <CircleSub>vs 8%</CircleSub>
            </Circle>
          </RowData>
          {/* {Object.keys(headers).map((key: string, index: number) => (
            <RowData key="">
              {index > 1 ? <Circle>{row[key]}</Circle> : index === 0 ? `${row[key]} (Details)` : row[key]}
            </RowData>
          ))}  */}
          {/* {Object.keys(headers).map((key: string, index: number) => (
            <RowData key="">
              {index > 1 ? <Circle>{row[key]}</Circle> : index === 0 ? `${row[key]} (Details)` : row[key]}
            </RowData>
          ))} */}
        </TableRow>
      ))}
    </Container>
  );
};

export default Dashboard;
