import React from 'react';
import { PanelProps } from '@grafana/data';
import { SimpleOptions } from 'types';
import { css} from 'emotion';
 import { stylesFactory} from '@grafana/ui';

interface Props extends PanelProps<SimpleOptions> {}

export const SimplePanel: React.FC<Props> = ({ options, data, width, height }) => {

  const newdata = [
    {
        "journeyId":"11",
        "journeyType":"update address",
        "journeyDetails":"details of aupdate address",
        "journeyNci":"998",
        "journeyTotalImpactedCustomers":"10000",
        "journeyFulfilmentPercentage":"10",
        "journeySuccessRatePercentage":"20",
        "journeyTimeTaken":"350",
        "journeyTotalFulfilmentPercentage":"10",
        "journeyTotalSuccessRatePercentage":"20",
        "journeyTotalTimeTaken":"350",
        "timestamp":"2022-04-05T18:02:35"
    },
    {
        "journeyId":"11",
        "journeyType":"update address",
        "journeyDetails":"details of aupdate address",
        "journeyNci":"998",
        "journeyTotalImpactedCustomers":"10000",
        "journeyFulfilmentPercentage":"10",
        "journeySuccessRatePercentage":"20",
        "journeyTimeTaken":"350",
        "journeyTotalFulfilmentPercentage":"10",
        "journeyTotalSuccessRatePercentage":"20",
        "journeyTotalTimeTaken":"350",
        "timestamp":"2022-04-05T18:04:38"
    }
]

const headings = Object.keys(newdata[0]);

  console.log(data)
  // const theme = useTheme();
  const styles = getStyles();
  return <div><table>
  <tr>
  {headings.map(( head, index ) => {
          return (
            <th key={index}>{head}</th>
          );
        })}
    </tr>
    
  {newdata.map(( listValue, index ) => {
          return (
            <tr key={index}>
              <td>{listValue.journeyId}</td>
              <td>{listValue.journeyType}</td>
              <td>{listValue.journeyDetails}</td>
              <td>{listValue.journeyNci}</td>
              <td>{listValue.journeyTotalImpactedCustomers}</td>
              <td><div className={styles.yello}>{listValue.journeyFulfilmentPercentage}</div></td>
              <td><div className={styles.red}>{listValue.journeySuccessRatePercentage}</div></td>
              <td><div className={styles.red}>{listValue.journeyTimeTaken}</div></td>
              <td>{listValue.journeyTotalFulfilmentPercentage}</td>
              <td>{listValue.journeyTotalSuccessRatePercentage}</td>
              <td>{listValue.journeyTotalTimeTaken}</td>
              <td>{listValue.timestamp}</td>
            </tr>
          );
        })}
</table></div>;
};

const getStyles = stylesFactory(() => {
  return {
    yello: css`
      width:100px;
      height:100px;
      border-radius:250px;
      font-size:20px;
      color:#fff;
      line-height:100px;
      text-align:center;
      background:#ac9e0f
    `,
    red: css`
      width:100px;
      height:100px;
      border-radius:250px;
      font-size:20px;
      color:#fff;
      line-height:100px;
      text-align:center;
      background:#cc0202
    `,
    green: css`
      position: absolute;
      bottom: 0;
      left: 0;
      padding: 10px;
    `,
  };
});
