import styled from 'styled-components';

export const Container = styled.div`
  height: 100%;
  width: 100%;
  margin: 20px;
  padding: 10px 20px;
  box-sizing: border-box;
  border: 2px solid grey;
  font-weight: bolder;
`;

export const RealTimeHeader = styled.div`
  height: 1.8rem;
  line-height: 1.7rem;
  background-color: #049f0b;
  color: white;
  text-align: center;
`;

export const HeaderRow = styled.div`
  margin-top: 0.5rem;
  display: flex;
  justify-content: space-between;
`;

export const ColumnHeader = styled.span`
  border: 1px solid slategray;
  padding: 0 1.5rem;
  margin: 5px;
  width: 10rem;
  flex: 1 1 auto;
  text-align: center;
`;

export const TableRow = styled.span`
  margin-top: 0.5rem;
  display: flex;
  justify-content: space-between;
  >span: nth-child(-n + 2) {
    color: #13c31b;
  }
  >span: nth-child(3) > div {
    background-color: #ffc107;
  }
`;

export const RowData = styled.span`
  padding: 0 1rem;
  margin: 5px;
  width: 10rem;
  flex: 1 1 auto;
  font-size: 0.9rem;
  margin: auto;
  font-weight: bold;
`;

export const Circle = styled.div`
  border-radius: 50%;
  width: 2.9rem;
  height: 2.9rem;
  line-height: 2.85rem;
  background-color: #c40606;
  text-align: center;
  margin: auto;
  color: white;
`;
