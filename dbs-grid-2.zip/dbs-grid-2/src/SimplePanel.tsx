import React, { useState } from 'react';
import { Circle, ColumnHeader, Container, HeaderRow, RealTimeHeader, RowData, TableRow } from './DashboardStyled';
import axios from 'axios';

interface TableHeaders {
  [key: string]: string;
}

const Dashboard = () => {
  const [gridData, setGridData] = useState<any>([{}]);
  const headers: TableHeaders = {
    journeyDetails: 'Journey',
    journeyTotalImpactedCustomers: 'NCI/Total Customers',
    journeyFulfilmentPercentage: 'Fullfilment Rate %',
    journeySuccessRatePercentage: 'Success Rate %',
    journeyTimeTaken: 'Time Taken S',
  };
  // axios.post(`https://5c282973-ad6e-45bd-94bb-9c382297ab6b.mock.pstmn.io/data/query`).then((res) => {
  //   const data = res.data;
  //   console.log('here -->', data);
  //   setGridData(data);
  // });
  axios.post(`https://nci-api.dev.apps.cs.sgp.dbs.com/api/journies`).then((res) => {
    const data = res.data;
    console.log('here -->', data);
    setGridData(data);
  });

  // const rowData: TableHeaders[] = [
  //   {
  //     journey: 'Personal Particular Update Address',
  //     totalCustomers: '1000 / 30000',
  //     fullfilmentRate: '82%',
  //     successRate: '72%',
  //     timeTaken: '420',
  //   },
  //   {
  //     journey: 'Journey 2 Sub Journey',
  //     totalCustomers: 'AA / BBBB',
  //     fullfilmentRate: 'X%',
  //     successRate: 'Y%',
  //     timeTaken: 'Z',
  //   },
  // ];

  return (
    <Container>
      <RealTimeHeader>Real-time view of past 30 minutes - refreshed every 30 minutes </RealTimeHeader>
      <HeaderRow>
        {Object.keys(headers).map((key: string) => (
          <ColumnHeader key="">{headers[key]}</ColumnHeader>
        ))}
      </HeaderRow>
      {gridData.map((row: any) => (
        <TableRow key="">
          {Object.keys(headers).map((key: string, index: number) => (
            <RowData key="">
              {index > 1 ? <Circle>{row[key]}</Circle> : index === 0 ? `${row[key]} (Details)` : row[key]}
            </RowData>
          ))}
        </TableRow>
      ))}
    </Container>
  );
};

export default Dashboard;
